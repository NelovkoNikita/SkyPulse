-- ============================================
-- SkyPulse: схема базы данных для Supabase
-- ============================================

-- Таблица избранных городов
create table public.favorites (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid references auth.users(id) on delete cascade not null,
  city_name   text not null,
  admin       text,
  country     text,
  lat         double precision not null,
  lon         double precision not null,
  created_at  timestamptz default now() not null,

  -- запрещаем дубликаты одного и того же города у одного пользователя
  unique (user_id, lat, lon)
);

-- Таблица истории поиска
create table public.search_history (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid references auth.users(id) on delete cascade not null,
  city_name   text not null,
  admin       text,
  country     text,
  lat         double precision not null,
  lon         double precision not null,
  searched_at timestamptz default now() not null
);

-- Индексы для быстрого поиска по пользователю
create index favorites_user_id_idx on public.favorites(user_id);
create index search_history_user_id_idx on public.search_history(user_id);
create index search_history_searched_at_idx on public.search_history(user_id, searched_at desc);

-- ============================================
-- Row Level Security (RLS)
-- ============================================

alter table public.favorites enable row level security;
alter table public.search_history enable row level security;

-- favorites: пользователь видит/меняет только свои записи
create policy "favorites_select_own"
on public.favorites for select
to authenticated
using ( (select auth.uid()) = user_id );

create policy "favorites_insert_own"
on public.favorites for insert
to authenticated
with check ( (select auth.uid()) = user_id );

create policy "favorites_delete_own"
on public.favorites for delete
to authenticated
using ( (select auth.uid()) = user_id );

-- search_history: пользователь видит/меняет только свои записи
create policy "search_history_select_own"
on public.search_history for select
to authenticated
using ( (select auth.uid()) = user_id );

create policy "search_history_insert_own"
on public.search_history for insert
to authenticated
with check ( (select auth.uid()) = user_id );

create policy "search_history_delete_own"
on public.search_history for delete
to authenticated
using ( (select auth.uid()) = user_id );
