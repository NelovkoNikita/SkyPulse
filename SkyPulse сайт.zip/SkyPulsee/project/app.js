    // ============================
    // Weather code mapping (Open-Meteo)
    // ============================
    const W = {
      0:{t:"Ясно",k:"sun"},1:{t:"Преимущественно ясно",k:"sun"},2:{t:"Переменная облачность",k:"cloud-sun"},3:{t:"Пасмурно",k:"cloud"},
      45:{t:"Туман",k:"fog"},48:{t:"Инейный туман",k:"fog"},
      51:{t:"Морось слабая",k:"drizzle"},53:{t:"Морось",k:"drizzle"},55:{t:"Морось сильная",k:"drizzle"},
      56:{t:"Ледяная морось",k:"drizzle"},57:{t:"Ледяная морось сильная",k:"drizzle"},
      61:{t:"Дождь слабый",k:"rain"},63:{t:"Дождь",k:"rain"},65:{t:"Дождь сильный",k:"rain"},
      66:{t:"Ледяной дождь",k:"rain"},67:{t:"Ледяной дождь сильный",k:"rain"},
      71:{t:"Снег слабый",k:"snow"},73:{t:"Снег",k:"snow"},75:{t:"Снег сильный",k:"snow"},77:{t:"Снежные зерна",k:"snow"},
      80:{t:"Ливень слабый",k:"rain"},81:{t:"Ливень",k:"rain"},82:{t:"Ливень сильный",k:"rain"},
      85:{t:"Снегопад слабый",k:"snow"},86:{t:"Снегопад сильный",k:"snow"},
      95:{t:"Гроза",k:"thunder"},96:{t:"Гроза с градом",k:"thunder"},99:{t:"Гроза с сильным градом",k:"thunder"},
    };

    const $ = (id) => document.getElementById(id);
    const clamp = (v,a,b)=>Math.max(a,Math.min(b,v));

    const state = {
      unit: "c",          // c | f
      lastQuery: "",
      geoTimer: null,
      selected: null,     // {name,country,admin,lat,lon}
      latestData: null,
      suggest: { items: [], active: -1 },
      mode: "today",      // today | week
      chart: { showTemp:true, showPop:true, hover:-1 },
      user: null,         // текущий авторизованный пользователь Supabase (или null)
      favorites: [],      // кэш избранных городов текущего пользователя
      historyCache: []    // кэш истории поиска текущего пользователя
    };

    // ============================
    // Supabase: инициализация и Auth
    // ============================
    const SUPABASE_URL = "https://unqawvxllggspvzlqyzs.supabase.co";
    const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVucWF3dnhsbGdnc3B2emxxeXpzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE2MTY4NTksImV4cCI6MjA5NzE5Mjg1OX0.-5YhwTENW1fLtfwpN6q4q3-foS6ZzaYx90BYA5CdcNA";

    const sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

    // --- Открытие / закрытие модалки авторизации ---
    function openAuthModal(view = "login"){
      $("authOverlay").classList.add("show");
      $("authOverlay").setAttribute("aria-hidden", "false");
      showAuthView(view);
    }
    function closeAuthModal(){
      $("authOverlay").classList.remove("show");
      $("authOverlay").setAttribute("aria-hidden", "true");
      $("loginMsg").textContent = "";
      $("registerMsg").textContent = "";
    }
    function showAuthView(view){
      $("loginView").style.display = view === "login" ? "block" : "none";
      $("registerView").style.display = view === "register" ? "block" : "none";
    }

    // --- Регистрация ---
    async function handleRegister(){
      const email = $("regEmail").value.trim();
      const password = $("regPassword").value;
      const msg = $("registerMsg");
      msg.className = "authMsg";
      msg.textContent = "";

      if (!email || !password){
        msg.textContent = "Заполните email и пароль.";
        msg.classList.add("err");
        return;
      }
      if (password.length < 6){
        msg.textContent = "Пароль должен быть не короче 6 символов.";
        msg.classList.add("err");
        return;
      }

      const { data, error } = await sb.auth.signUp({ email, password });
      if (error){
        msg.textContent = "Ошибка: " + error.message;
        msg.classList.add("err");
        return;
      }
      msg.textContent = "Аккаунт создан! Вход выполняется...";
      msg.classList.add("ok");

      // Если подтверждение email отключено в настройках проекта — сессия появится сразу
      if (data.session){
        setTimeout(closeAuthModal, 600);
      } else {
        msg.textContent = "Проверьте почту для подтверждения регистрации.";
      }
    }

    // --- Вход ---
    async function handleLogin(){
      const email = $("loginEmail").value.trim();
      const password = $("loginPassword").value;
      const msg = $("loginMsg");
      msg.className = "authMsg";
      msg.textContent = "";

      if (!email || !password){
        msg.textContent = "Заполните email и пароль.";
        msg.classList.add("err");
        return;
      }

      const { error } = await sb.auth.signInWithPassword({ email, password });
      if (error){
        msg.textContent = "Ошибка: " + error.message;
        msg.classList.add("err");
        return;
      }
      msg.textContent = "Успешный вход!";
      msg.classList.add("ok");
      setTimeout(closeAuthModal, 400);
    }

    // --- Выход ---
    async function handleLogout(){
      await sb.auth.signOut();
    }

    // --- Реакция на изменение состояния авторизации (вход/выход/восстановление сессии) ---
    function applyAuthUI(){
      const btn = $("authBtnLabel");
      const panel = $("userPanel");
      const star = $("favStarBtn");

      if (state.user){
        btn.textContent = state.user.email.split("@")[0] + " · Выйти";
        panel.style.display = "block";
        star.style.display = "inline-block";
        loadFavorites();
        loadHistory();
      } else {
        btn.textContent = "Войти";
        panel.style.display = "none";
        star.style.display = "none";
        $("clearHistoryBtn").style.display = "none";
        state.favorites = [];
        state.historyCache = [];
      }
    }

    sb.auth.onAuthStateChange((_event, session) => {
      state.user = session ? session.user : null;
      applyAuthUI();
    });

    // ============================
    // Supabase: Избранные города
    // ============================
    async function loadFavorites(){
      if (!state.user) return;
      const { data, error } = await sb
        .from("favorites")
        .select("*")
        .order("created_at", { ascending: false });

      if (error){ console.error("loadFavorites:", error.message); return; }
      state.favorites = data || [];
      renderFavorites();
      updateFavStarUI();
    }

    function renderFavorites(){
      const box = $("favList");
      if (!state.favorites.length){
        box.innerHTML = `<div class="emptyHint">Пока нет избранных городов. Нажмите ☆ рядом с названием города.</div>`;
        return;
      }
      box.innerHTML = state.favorites.map(f => `
        <div class="favRow" data-lat="${f.lat}" data-lon="${f.lon}" data-name="${escapeHTML(f.city_name)}" data-admin="${escapeHTML(f.admin||"")}" data-country="${escapeHTML(f.country||"")}">
          <span class="name">${escapeHTML(f.city_name)}${f.country ? ", " + escapeHTML(f.country) : ""}</span>
          <button class="del" type="button" data-id="${f.id}" title="Удалить из избранного">✕</button>
        </div>
      `).join("");

      box.querySelectorAll(".favRow").forEach(row => {
        row.addEventListener("click", (ev) => {
          if (ev.target.closest(".del")) return;
          const p = {
            name: row.dataset.name, admin: row.dataset.admin,
            country: row.dataset.country,
            lat: parseFloat(row.dataset.lat), lon: parseFloat(row.dataset.lon)
          };
          selectPlace(p);
        });
      });
      box.querySelectorAll(".del").forEach(btn => {
        btn.addEventListener("click", async (ev) => {
          ev.stopPropagation();
          await removeFavoriteById(btn.dataset.id);
        });
      });
    }

    async function isFavorite(lat, lon){
      return state.favorites.some(f => Math.abs(f.lat-lat) < 1e-6 && Math.abs(f.lon-lon) < 1e-6);
    }

    function updateFavStarUI(){
      const star = $("favStarBtn");
      if (!state.user || !state.selected){ return; }
      const fav = state.favorites.some(f => Math.abs(f.lat-state.selected.lat) < 1e-6 && Math.abs(f.lon-state.selected.lon) < 1e-6);
      star.textContent = fav ? "★" : "☆";
      star.title = fav ? "Убрать из избранного" : "В избранное";
    }

    async function toggleFavoriteCurrent(){
      if (!state.user){ openAuthModal("login"); return; }
      if (!state.selected) return;
      const p = state.selected;
      const existing = state.favorites.find(f => Math.abs(f.lat-p.lat) < 1e-6 && Math.abs(f.lon-p.lon) < 1e-6);

      if (existing){
        await removeFavoriteById(existing.id);
        return;
      }

      const { data, error } = await sb.from("favorites").insert({
        user_id: state.user.id,
        city_name: p.name, admin: p.admin || null, country: p.country || null,
        lat: p.lat, lon: p.lon
      }).select();

      if (error){ console.error("addFavorite:", error.message); return; }
      state.favorites.unshift(data[0]);
      renderFavorites();
      updateFavStarUI();
    }

    async function removeFavoriteById(id){
      const { error } = await sb.from("favorites").delete().eq("id", id);
      if (error){ console.error("removeFavorite:", error.message); return; }
      state.favorites = state.favorites.filter(f => f.id !== id);
      renderFavorites();
      updateFavStarUI();
    }

    // ============================
    // Supabase: История поиска
    // ============================
    async function addToHistory(p){
      if (!state.user) return;
      const { data, error } = await sb.from("search_history").insert({
        user_id: state.user.id,
        city_name: p.name, admin: p.admin || null, country: p.country || null,
        lat: p.lat, lon: p.lon
      }).select();

      if (error){ console.error("addToHistory:", error.message); return; }

      // обновляем локальный список без повторного запроса к серверу
      state.historyCache = state.historyCache || [];
      state.historyCache.unshift(data[0]);
      state.historyCache = state.historyCache.slice(0, 10);
      renderHistory(state.historyCache);
    }

    async function loadHistory(){
      if (!state.user) return;
      const { data, error } = await sb
        .from("search_history")
        .select("*")
        .order("searched_at", { ascending: false })
        .limit(10);

      if (error){ console.error("loadHistory:", error.message); return; }
      state.historyCache = data || [];
      renderHistory(state.historyCache);
    }

    function renderHistory(items){
      const box = $("historyList");
      const clearBtn = $("clearHistoryBtn");

      if (!items.length){
        box.innerHTML = `<div class="emptyHint">История поиска пока пуста.</div>`;
        clearBtn.style.display = "none";
        return;
      }
      clearBtn.style.display = "inline-block";

      box.innerHTML = items.map(h => `
        <div class="favRow" data-lat="${h.lat}" data-lon="${h.lon}" data-name="${escapeHTML(h.city_name)}" data-admin="${escapeHTML(h.admin||"")}" data-country="${escapeHTML(h.country||"")}">
          <span class="name">${escapeHTML(h.city_name)}${h.country ? ", " + escapeHTML(h.country) : ""}</span>
        </div>
      `).join("");

      box.querySelectorAll(".favRow").forEach(row => {
        row.addEventListener("click", () => {
          const p = {
            name: row.dataset.name, admin: row.dataset.admin,
            country: row.dataset.country,
            lat: parseFloat(row.dataset.lat), lon: parseFloat(row.dataset.lon)
          };
          selectPlace(p);
        });
      });
    }

    async function clearHistory(){
      if (!state.user) return;
      if (!confirm("Удалить всю историю поиска? Это действие нельзя отменить.")) return;

      const { error } = await sb
        .from("search_history")
        .delete()
        .eq("user_id", state.user.id);

      if (error){ console.error("clearHistory:", error.message); return; }
      state.historyCache = [];
      renderHistory([]);
    }

    // ============================
    // UI helpers
    // ============================
    function setStatus(text){ $("status").textContent = text; }

    function fmtTempC(c){
      if (c == null || Number.isNaN(c)) return "—";
      if (state.unit === "c") return `${Math.round(c)}<small>°C</small>`;
      const f = (c * 9/5) + 32;
      return `${Math.round(f)}<small>°F</small>`;
    }
    function fmtTempSmall(c){
      if (c == null || Number.isNaN(c)) return "—";
      return state.unit === "c" ? `${Math.round(c)}°C` : `${Math.round(c*9/5+32)}°F`;
    }
    function fmtSpeedKmh(kmh){
      if (kmh == null || Number.isNaN(kmh)) return "—";
      const v = state.unit === "c" ? kmh : (kmh / 1.60934); // mph in f-mode
      const u = state.unit === "c" ? "км/ч" : "mph";
      return `${Math.round(v)} ${u}`;
    }
    function prettyPlace(p){
      if (!p) return "—";
      const admin = p.admin ? `, ${p.admin}` : "";
      const country = p.country ? `, ${p.country}` : "";
      return `${p.name}${admin}${country}`;
    }
    function nowLine(nowISO, tz){
      try{
        const d = new Date(nowISO);
        return new Intl.DateTimeFormat("ru-RU", { weekday:"long", hour:"2-digit", minute:"2-digit", timeZone: tz || "UTC" }).format(d);
      }catch{ return "—"; }
    }
    // Показывает настоящее текущее время (системные часы устройства), переведённое
    // в таймзону города. В отличие от nowLine() не зависит от поля current.time API,
    // которое в архивном (historical-forecast) хосте может отставать от реальности.
    function nowLineRealTime(tz){
      try{
        return new Intl.DateTimeFormat("ru-RU", { weekday:"long", hour:"2-digit", minute:"2-digit", timeZone: tz || "UTC" }).format(new Date());
      }catch{ return "—"; }
    }
    function dow(dateStr, tz){
      const d = new Date(dateStr + "T12:00:00");
      return new Intl.DateTimeFormat("ru-RU", { weekday:"short", day:"2-digit", month:"2-digit", timeZone: tz || "UTC" }).format(d);
    }

    function iconSVG(kind){
      const s = `stroke="rgba(234,240,255,.88)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"`;
      if (kind === "sun") return `
        <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true">
          <circle cx="12" cy="12" r="4" ${s}></circle>
          <path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.6 4.6l1.4 1.4M18 18l1.4 1.4M19.4 4.6 18 6M6 18l-1.4 1.4" ${s}></path>
        </svg>`;
      if (kind === "cloud-sun") return `
        <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true">
          <path d="M8 16H6.5a3.5 3.5 0 1 1 .8-6.9A5 5 0 0 1 17 10.2" ${s}></path>
          <path d="M16 16h2.2a3 3 0 1 0-.5-6" ${s}></path>
          <path d="M12 3v2M4 11H2M6 5l1.4 1.4M18 5l-1.4 1.4" ${s}></path>
          <circle cx="12" cy="8" r="2.5" ${s}></circle>
        </svg>`;
      if (kind === "cloud") return `
        <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true">
          <path d="M7 18h10a4 4 0 0 0 .7-8 6 6 0 0 0-11.6 1.6A3.5 3.5 0 0 0 7 18Z" ${s}></path>
        </svg>`;
      if (kind === "fog") return `
        <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true">
          <path d="M3 10h18M6 14h12M4 18h16" ${s}></path>
          <path d="M7 10a5 5 0 0 1 10 0" ${s}></path>
        </svg>`;
      if (kind === "drizzle") return `
        <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true">
          <path d="M7 14h10a4 4 0 0 0 .7-8 6 6 0 0 0-11.6 1.6A3.5 3.5 0 0 0 7 14Z" ${s}></path>
          <path d="M8 17v2M12 17v2M16 17v2" ${s}></path>
        </svg>`;
      if (kind === "rain") return `
        <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true">
          <path d="M7 13h10a4 4 0 0 0 .7-8 6 6 0 0 0-11.6 1.6A3.5 3.5 0 0 0 7 13Z" ${s}></path>
          <path d="M9 16l-1 3M13 16l-1 3M17 16l-1 3" ${s}></path>
        </svg>`;
      if (kind === "snow") return `
        <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true">
          <path d="M7 13h10a4 4 0 0 0 .7-8 6 6 0 0 0-11.6 1.6A3.5 3.5 0 0 0 7 13Z" ${s}></path>
          <path d="M9 17h0M12 18h0M15 17h0M10 20h0M14 20h0" ${s}></path>
        </svg>`;
      if (kind === "thunder") return `
        <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true">
          <path d="M7 13h10a4 4 0 0 0 .7-8 6 6 0 0 0-11.6 1.6A3.5 3.5 0 0 0 7 13Z" ${s}></path>
          <path d="M13 14l-3 5h3l-2 4" ${s}></path>
        </svg>`;
      return `<svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2v20M2 12h20" ${s}></path></svg>`;
    }

    function chooseTheme(code, isDay){
      const k = (W[code] || {k:"cloud"}).k;
      const night = !isDay;
      if (k === "sun" && night) return "clear-night";
      if (k === "sun") return "sunny";
      if (k === "cloud-sun") return night ? "cloudy" : "cloudy";
      if (k === "cloud") return "cloudy";
      if (k === "fog") return "fog";
      if (k === "drizzle") return "rain";
      if (k === "rain") return "rain";
      if (k === "snow") return "snow";
      if (k === "thunder") return "thunder";
      return night ? "clear-night" : "cloudy";
    }

    function renderSkeleton(){
      $("place").innerHTML = `<div class="skeleton" style="width:240px;height:16px"></div>`;
      $("timeLine").innerHTML = `<div class="skeleton" style="width:200px"></div>`;
      $("nowText").innerHTML = `<div class="skeleton" style="width:160px"></div>`;
      $("feelText").innerHTML = `<div class="skeleton" style="width:120px"></div>`;
      $("temp").innerHTML = `<div class="skeleton" style="width:220px;height:52px;border-radius:18px"></div>`;
      $("wind").textContent = "—";
      $("hum").textContent = "—";
      $("clouds").textContent = "—";
      $("pop").textContent = "—";
      $("days").innerHTML = Array.from({length:7}).map(()=>`
        <div class="day">
          <div>
            <div class="skeleton" style="width:70px"></div>
            <div class="skeleton" style="width:44px;margin-top:10px;height:32px;border-radius:12px"></div>
            <div class="skeleton" style="width:90px;margin-top:10px"></div>
          </div>
          <div class="skeleton" style="width:100%;height:12px"></div>
        </div>
      `).join("");
      $("chartRange").innerHTML = `<span class="skeleton" style="display:inline-block;width:180px"></span>`;
      $("hoverReadout").innerHTML = `<b>—</b>`;
    }

    // ============================
    // Search highlight in suggestions
    // ============================
    function escapeHTML(s){
      return (s ?? "").replace(/[&<>"']/g, (c)=>({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;" }[c]));
    }
    function highlight(text, query){
      const t = escapeHTML(text);
      const q = (query||"").trim();
      if (!q) return t;

      // безопасная подсветка каждого токена
      const tokens = q.split(/\s+/).filter(Boolean).slice(0,3);
      let out = t;
      for (const tok of tokens){
        const re = new RegExp(`(${tok.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`, "ig");
        out = out.replace(re, `<span class="hl">$1</span>`);
      }
      return out;
    }

    // ============================
    // Open-Meteo API
    // ============================
   async function geoSearch(name){
  const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(name)}&count=12&language=ru&format=json`;
  const r = await fetch(url);
  if (!r.ok) throw new Error("Geo API error");
  return await r.json();
}

const WORKER_PROXY_URL = "https://skypulse-weather-proxy.onrender.com";

function buildForecastParams(lat, lon){
  return `latitude=${encodeURIComponent(lat)}&longitude=${encodeURIComponent(lon)}`
    + `&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,cloud_cover,wind_speed_10m,wind_direction_10m`
    + `&hourly=temperature_2m,precipitation_probability,precipitation,weather_code`
    + `&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max,sunrise,sunset`
    + `&timezone=auto`;
}

async function fetchForecast(lat, lon){
  const params = buildForecastParams(lat, lon);

  // 1) пробуем собственный прокси (Render web service) — свежие данные без
  //    задержки публикации, и доступен в России без VPN (домен onrender.com).
  if (WORKER_PROXY_URL && !WORKER_PROXY_URL.includes("ВАШ-СЕРВИС")){
    try{
      setStatus("Подключаюсь к серверу свежих данных…");
      const proxyUrl = `${WORKER_PROXY_URL}/?${params}`;
      const r = await fetch(proxyUrl, { signal: AbortSignal.timeout(55000) });
      if (r.ok) return await r.json();
      if (r.status === 429){
        console.warn("Render-прокси: лимит запросов Open-Meteo исчерпан (429), переключаюсь на архивный API");
      }
    }catch(e){
      console.warn("Render-прокси недоступен, переключаюсь на архивный API:", e.message);
    }
  }

  // 2) запасной вариант: архивный хост Open-Meteo (данные с задержкой ~2 дня,
  //    но физически доступен без VPN из России)
  const fallbackUrl = `https://historical-forecast-api.open-meteo.com/v1/forecast?${params}`;
  const r2 = await fetch(fallbackUrl);
  if (!r2.ok) throw new Error("Weather API error");
  return await r2.json();
}

    function normalizeGeoResult(r){
      return {
        name: r.name,
        admin: r.admin1 || r.admin2 || "",
        country: r.country || "",
        lat: r.latitude,
        lon: r.longitude
      };
    }

    // ============================
    // Suggestions (autocomplete)
    // ============================
    function closeSuggest(){
      $("suggest").classList.remove("show");
      $("suggest").innerHTML = "";
      state.suggest.items = [];
      state.suggest.active = -1;
    }

    function renderSuggestions(items, query){
      const box = $("suggest");
      if (!items.length){ closeSuggest(); return; }

      state.suggest.items = items;
      state.suggest.active = 0;

      box.innerHTML = items.map((p, idx) => {
        const left = `${p.name}${p.admin ? ", " + p.admin : ""}`;
        const meta = `${p.country || ""} • ${p.lat.toFixed(2)}, ${p.lon.toFixed(2)}`;
        return `
          <button class="row ${idx===0?"active":""}" type="button" data-i="${idx}">
            <span>${highlight(left, query)}</span>
            <span class="meta">${escapeHTML(meta)}</span>
          </button>
        `;
      }).join("") + `
        <div class="hintline">
          <span>↑/↓ выбрать • Enter применить • Esc закрыть</span>
          <span>${items.length} вариантов</span>
        </div>
      `;

      box.classList.add("show");

      box.querySelectorAll("button.row").forEach(btn=>{
        btn.addEventListener("mouseenter", () => setActiveSuggest(+btn.dataset.i));
        btn.addEventListener("click", () => pickSuggest(+btn.dataset.i));
      });
    }

    function setActiveSuggest(i){
      const box = $("suggest");
      const rows = [...box.querySelectorAll("button.row")];
      if (!rows.length) return;

      state.suggest.active = clamp(i, 0, rows.length-1);
      rows.forEach((r, idx) => r.classList.toggle("active", idx === state.suggest.active));
    }

    function pickSuggest(i){
      const item = state.suggest.items[i];
      if (!item) return;
      $("q").value = `${item.name}${item.admin ? ", "+item.admin : ""}`;
      closeSuggest();
      loadForPlace(item);
    }

    function filterResultsLocally(items, query){
      const q = (query||"").trim().toLowerCase();
      if (!q) return items;

      // приоритет: startsWith и совпадение токенов
      const tokens = q.split(/\s+/).filter(Boolean);
      const score = (p)=>{
        const left = `${p.name} ${p.admin||""} ${p.country||""}`.toLowerCase();
        let s = 0;
        if (left.startsWith(q)) s += 40;
        for (const t of tokens){
          if (left.includes(t)) s += 10;
          if (p.name.toLowerCase().startsWith(t)) s += 6;
        }
        // лёгкая стабилизация по длине (короче — выше)
        s += Math.max(0, 6 - Math.min(6, p.name.length/6));
        return s;
      };

      return items
        .map(p => ({p, s: score(p)}))
        .filter(x => x.s > 0)
        .sort((a,b)=>b.s-a.s)
        .map(x=>x.p);
    }

    // ============================
    // Rendering weather + weekly forecast
    // ============================
    function render(data, placeObj){
      const tz = data.timezone || "UTC";
      const cur = data.current || data.current_weather || {};
      const code = cur.weather_code ?? cur.weathercode ?? 3;
      const isDay = (cur.is_day ?? cur.is_day === 0 ? !!cur.is_day : true);

      const winfo = W[code] || { t: "Погода", k: "cloud" };
      document.body.setAttribute("data-theme", chooseTheme(code, isDay));
      fxSetMode(winfo.k, isDay);

      $("place").textContent = prettyPlace(placeObj);
      // cur.time от historical-forecast-api может отставать от реального момента
      // (архивная задержка публикации), поэтому для отображения "текущего времени
      // города" используем настоящее системное время, переведённое в таймзону города,
      // а не значение из ответа API.
      $("timeLine").textContent = nowLineRealTime(tz);

      $("nowIcon").innerHTML = iconSVG(winfo.k);
      $("nowText").textContent = winfo.t;

      const tempC = cur.temperature_2m ?? cur.temperature ?? null;
      const appC  = cur.apparent_temperature ?? null;

      $("temp").innerHTML = fmtTempC(tempC);
      $("feelText").textContent = appC != null ? `Ощущается: ${state.unit==="c" ? Math.round(appC)+"°C" : Math.round(appC*9/5+32)+"°F"}` : "—";

      const wind = cur.wind_speed_10m ?? cur.windspeed ?? null;
      $("wind").textContent = fmtSpeedKmh(wind);

      const hum = cur.relative_humidity_2m ?? null;
      $("hum").textContent = hum != null ? `${Math.round(hum)}%` : "—";

      const cloud = cur.cloud_cover ?? null;
      $("clouds").textContent = cloud != null ? `${Math.round(cloud)}%` : "—";

      const pop = data.daily?.precipitation_probability_max?.[0];
      $("pop").textContent = (pop != null && !Number.isNaN(pop)) ? `${Math.round(pop)}%` : "—";

      // weekly
      const d = data.daily || {};
      const days = d.time || [];
      const max = d.temperature_2m_max || [];
      const min = d.temperature_2m_min || [];
      const wcd = d.weather_code || [];
      const pp  = d.precipitation_probability_max || [];

      $("rangeHint").textContent = days.length ? `с ${days[0]} по ${days[Math.min(days.length-1, 6)]} (таймзона: ${tz})` : "—";

      $("days").innerHTML = days.slice(0,7).map((day, i) => {
        const info = W[wcd[i]] || {t:"—", k:"cloud"};
        const tmax = max[i], tmin = min[i];
        const tmaxHtml = (tmax==null) ? "—" : (state.unit==="c" ? `${Math.round(tmax)}°` : `${Math.round(tmax*9/5+32)}°`);
        const tminTxt  = (tmin==null) ? "—" : (state.unit==="c" ? `${Math.round(tmin)}°` : `${Math.round(tmin*9/5+32)}°`);
        const popTxt   = (pp[i]==null) ? "—" : `${Math.round(pp[i])}%`;
        return `
          <div class="day" title="${info.t}">
            <div>
              <p class="dow">${dow(day, tz)}</p>
              <div class="dmeta" style="margin-top:10px">
                <div class="wicon">${iconSVG(info.k)}</div>
                <div style="text-align:right">
                  <div class="dtemp">${tmaxHtml}</div>
                  <div class="dmin">мин: ${tminTxt}</div>
                </div>
              </div>
            </div>
            <div class="dmeta">
              <span>${info.t}</span>
              <span>🌧️ ${popTxt}</span>
            </div>
          </div>
        `;
      }).join("");

      // footer
      const lat = data.latitude?.toFixed?.(3);
      const lon = data.longitude?.toFixed?.(3);
      $("foot").textContent = lat && lon ? `Координаты: ${lat}, ${lon} • Таймзона: ${tz}` : `Таймзона: ${tz}`;

      // hourly chart
      buildHourlySeries(data, tz);
      drawChart();
    }

    async function loadForPlace(placeObj){
      state.selected = placeObj;
      setStatus("Загружаю данные…");
      renderSkeleton();
      try{
        const data = await fetchForecast(placeObj.lat, placeObj.lon);
        state.latestData = data;
        render(data, placeObj);
        setStatus("Обновлено");
        updateFavStarUI();
        if (state.user) addToHistory(placeObj);
      }catch(e){
        console.error(e);
        setStatus("Ошибка загрузки данных. Проверь интернет или попробуй другой город.");
      }
    }

    // alias: используется кодом избранного/истории для перехода к городу
    function selectPlace(placeObj){
      $("q").value = `${placeObj.name}${placeObj.admin ? ", "+placeObj.admin : ""}`;
      loadForPlace(placeObj);
    }

    // ============================
    // Экспорт прогноза в CSV
    // ============================
    function csvEscape(val){
      const s = (val == null) ? "" : String(val);
      if (/[",\n;]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
      return s;
    }

    function downloadCSV(filename, rows){
      const csvBody = rows.map(r => r.map(csvEscape).join(";")).join("\r\n");
      const BOM = "\uFEFF"; // чтобы Excel корректно показывал кириллицу
      const blob = new Blob([BOM + csvBody], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }

    function exportHourlyCSV(){
      const tempUnit = state.unit === "c" ? "°C" : "°F";
      const rows = [["Время", `Температура (${tempUnit})`, "Вероятность осадков (%)"]];
      const times = chart.series.times || [];
      const tempC = chart.series.tempC || [];
      const pop = chart.series.pop || [];

      for (let i = 0; i < times.length; i++){
        const t = tempC[i];
        const tOut = (t == null) ? "" : (state.unit === "c" ? Math.round(t) : Math.round(t*9/5+32));
        rows.push([times[i] || "", tOut, pop[i] ?? ""]);
      }
      return rows;
    }

    function exportWeeklyCSV(){
      const tempUnit = state.unit === "c" ? "°C" : "°F";
      const rows = [["Дата", `Макс. температура (${tempUnit})`, `Мин. температура (${tempUnit})`, "Вероятность осадков (%)", "Погодное явление"]];
      const d = state.latestData?.daily || {};
      const days = d.time || [];
      const max = d.temperature_2m_max || [];
      const min = d.temperature_2m_min || [];
      const wcd = d.weather_code || [];
      const pp = d.precipitation_probability_max || [];

      for (let i = 0; i < days.length; i++){
        const cvt = (v) => v == null ? "" : (state.unit === "c" ? Math.round(v) : Math.round(v*9/5+32));
        const info = W[wcd[i]] || { t: "—" };
        rows.push([days[i] || "", cvt(max[i]), cvt(min[i]), pp[i] ?? "", info.t]);
      }
      return rows;
    }

    function handleExportCSV(){
      if (!state.latestData || !state.selected){
        setStatus("Сначала выберите город — нет данных для экспорта.");
        return;
      }
      const place = prettyPlace(state.selected).replace(/[^\p{L}\p{N}]+/gu, "_");
      const dateStr = new Date().toISOString().slice(0,10);
      const isToday = state.mode === "today";
      const rows = isToday ? exportHourlyCSV() : exportWeeklyCSV();
      const suffix = isToday ? "hourly" : "weekly";
      downloadCSV(`skypulse_${place}_${suffix}_${dateStr}.csv`, rows);
    }

    // ============================
    // Tabs: Today / Week
    // ============================
    function setMode(mode){
      state.mode = mode;
      const isToday = mode === "today";
      $("tabToday").classList.toggle("active", isToday);
      $("tabWeek").classList.toggle("active", !isToday);
      $("tabToday").setAttribute("aria-selected", isToday ? "true" : "false");
      $("tabWeek").setAttribute("aria-selected", !isToday ? "true" : "false");

      $("todayPanel").classList.toggle("show", isToday);
      // weekly forecast card is always visible; but user asked for switcher:
      const forecastSection = document.querySelector("section.card.forecast");
      forecastSection.style.display = isToday ? "none" : "block";
      if (isToday) {
        drawChart();
      } else {
        // принудительный reflow: гарантирует, что .days получит верную ширину
        // контейнера после смены display у родительской секции
        void forecastSection.offsetHeight;
        if (state.latestData) render(state.latestData, state.selected);
      }
    }

    // ============================
    // Hourly Chart (canvas)
    // ============================
    const chart = {
      canvas: null, ctx: null,
      series: { times: [], tempC: [], pop: [] },
      tz: "UTC",
      bounds: { left:40, right:14, top:14, bottom:30 },
    };

    function buildHourlySeries(data, tz){
      chart.tz = tz || "UTC";
      const h = data.hourly || {};
      const times = h.time || [];
      const tempC = h.temperature_2m || [];
      const pop   = h.precipitation_probability || [];

      // Архивный API (historical-forecast-api) используется для доступности без VPN,
      const nowInTZ = nowISOInTimezone(chart.tz);
      let startIdx = findNearestFutureIndex(times, nowInTZ);

      // защита: если данные обрываются раньше "сейчас" (архивная задержка свежее 24ч),
      // откатываемся на последние доступные 24 часа, чтобы график не схлопнулся в 1-2 точки
      if (startIdx < 0 || startIdx > times.length - 2){
        startIdx = Math.max(0, times.length - 24);
      }

      const slice = (arr)=>arr.slice(startIdx, startIdx + 24);
      chart.series.times = slice(times);
      chart.series.tempC = slice(tempC);
      chart.series.pop   = slice(pop);

      // range label
      const t0 = chart.series.times[0];
      const t1 = chart.series.times[chart.series.times.length-1];
      $("chartRange").textContent = t0 && t1 ? `${fmtHour(t0)} → ${fmtHour(t1)} (${chart.tz})` : "—";
    }

    // Возвращает ISO-строку текущего момента "как если бы" она была в таймзоне города,
    // в формате YYYY-MM-DDTHH:00, совпадающем с форматом hourly.time от Open-Meteo
    function nowISOInTimezone(tz){
      try{
        const parts = new Intl.DateTimeFormat("en-CA", {
          timeZone: tz, year:"numeric", month:"2-digit", day:"2-digit", hour:"2-digit", hour12:false
        }).formatToParts(new Date());
        const get = (type) => parts.find(p => p.type === type)?.value;
        let hour = get("hour");
        if (hour === "24") hour = "00"; // некоторые движки отдают полночь как 24
        return `${get("year")}-${get("month")}-${get("day")}T${hour}:00`;
      }catch{
        return new Date().toISOString().slice(0,13) + ":00";
      }
    }

    // Находит индекс первого элемента times, который >= nowISO (тот же час или позже)
    function findNearestFutureIndex(times, nowISO){
      for (let i = 0; i < times.length; i++){
        if (times[i] >= nowISO) return i;
      }
      return -1;
    }

    function fmtHour(iso){
      try{
        const d = new Date(iso);
        return new Intl.DateTimeFormat("ru-RU", { hour:"2-digit", minute:"2-digit", timeZone: chart.tz }).format(d);
      }catch{ return "—"; }
    }

    function fitCanvasToCSS(c){
      const rect = c.getBoundingClientRect();
      const dpr = Math.max(1, window.devicePixelRatio || 1);
      const w = Math.floor(rect.width * dpr);
      const h = Math.floor(rect.height * dpr);
      if (c.width !== w || c.height !== h){
        c.width = w; c.height = h;
      }
      return { w, h, dpr };
    }

    function drawChart(){
      if (!state.latestData) return;
      if (!chart.canvas){
        chart.canvas = $("chart");
        chart.ctx = chart.canvas.getContext("2d");
        chart.canvas.addEventListener("mousemove", onChartMove);
        chart.canvas.addEventListener("mouseleave", () => { state.chart.hover = -1; $("hoverReadout").innerHTML = `<b>—</b>`; drawChart(); });
        window.addEventListener("resize", () => drawChart());
      }

      const ctx = chart.ctx;
      const { w, h } = fitCanvasToCSS(chart.canvas);

      const pad = chart.bounds;
      const innerW = w - pad.left - pad.right;
      const innerH = h - pad.top - pad.bottom;

      ctx.clearRect(0,0,w,h);

      // background grid
      ctx.save();
      ctx.globalAlpha = 0.8;

      const gridLines = 4;
      for (let i=0;i<=gridLines;i++){
        const y = pad.top + (innerH * i / gridLines);
        ctx.beginPath();
        ctx.moveTo(pad.left, y);
        ctx.lineTo(w - pad.right, y);
        ctx.strokeStyle = "rgba(255,255,255,.10)";
        ctx.lineWidth = 1;
        ctx.stroke();
      }
      ctx.restore();

      const n = chart.series.times.length;
      if (!n) return;

      const xs = Array.from({length:n}, (_,i)=> pad.left + (innerW * (n===1 ? 0 : i/(n-1))));

      // ranges
      const temps = chart.series.tempC.filter(v=>v!=null && !Number.isNaN(v));
      const pops  = chart.series.pop.filter(v=>v!=null && !Number.isNaN(v));
      const tMin = temps.length ? Math.min(...temps) : 0;
      const tMax = temps.length ? Math.max(...temps) : 1;
      const pMin = 0;
      const pMax = 100;

      const yTemp = (c)=>{
        // temp line is upper weighted
        const v = c ?? tMin;
        const k = (v - tMin) / (tMax - tMin || 1);
        return pad.top + innerH * (1 - clamp(k,0,1));
      };
      const yPop = (p)=>{
        const v = p ?? 0;
        const k = (v - pMin) / (pMax - pMin || 1);
        return pad.top + innerH * (1 - clamp(k,0,1));
      };

      // pop area
      if (state.chart.showPop){
        ctx.save();
        ctx.beginPath();
        ctx.moveTo(xs[0], pad.top + innerH);
        for (let i=0;i<n;i++){
          ctx.lineTo(xs[i], yPop(chart.series.pop[i]));
        }
        ctx.lineTo(xs[n-1], pad.top + innerH);
        ctx.closePath();
        ctx.fillStyle = `rgba(255,255,255,.06)`;
        ctx.fill();
        // outline
        ctx.beginPath();
        for (let i=0;i<n;i++){
          const x = xs[i], y = yPop(chart.series.pop[i]);
          if (i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
        }
        ctx.strokeStyle = `rgba(255,255,255,.22)`;
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.restore();
      }

      // temp line
      if (state.chart.showTemp){
        ctx.save();
        ctx.beginPath();
        for (let i=0;i<n;i++){
          const x = xs[i], y = yTemp(chart.series.tempC[i]);
          if (i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
        }
        ctx.strokeStyle = `rgba(255,255,255,.86)`;
        ctx.lineWidth = 3;
        ctx.lineJoin = "round";
        ctx.lineCap = "round";
        ctx.stroke();

        // points
        for (let i=0;i<n;i++){
          const x = xs[i], y = yTemp(chart.series.tempC[i]);
          ctx.beginPath();
          ctx.arc(x,y, 4, 0, Math.PI*2);
          ctx.fillStyle = `rgba(255,255,255,.88)`;
          ctx.fill();
        }
        ctx.restore();
      }

      // x labels (every 3 hours)
      ctx.save();
      ctx.fillStyle = "rgba(234,240,255,.75)";
      ctx.font = `${Math.max(11, Math.round(h/18))}px ui-sans-serif, system-ui`;
      ctx.textAlign = "center";
      ctx.textBaseline = "top";
      for (let i=0;i<n;i++){
        if (i % 3 !== 0 && i !== n-1) continue;
        const label = fmtHour(chart.series.times[i]);
        ctx.fillText(label, xs[i], pad.top + innerH + 8);
      }
      ctx.restore();

      // y labels (temp min/max)
      ctx.save();
      ctx.fillStyle = "rgba(234,240,255,.70)";
      ctx.font = "12px ui-sans-serif, system-ui";
      ctx.textAlign = "left";
      ctx.textBaseline = "middle";
      ctx.fillText(`${fmtTempSmall(tMax)}`, 10, yTemp(tMax));
      ctx.fillText(`${fmtTempSmall(tMin)}`, 10, yTemp(tMin));
      ctx.restore();

      // hover
      if (state.chart.hover >= 0){
        const i = state.chart.hover;
        const x = xs[i];
        ctx.save();
        ctx.beginPath();
        ctx.moveTo(x, pad.top);
        ctx.lineTo(x, pad.top + innerH);
        ctx.strokeStyle = "rgba(255,255,255,.25)";
        ctx.lineWidth = 2;
        ctx.stroke();

        // marker bubble
        const tt = chart.series.tempC[i];
        const pp = chart.series.pop[i];
        const ttxt = tt==null ? "—" : (state.unit==="c" ? `${Math.round(tt)}°C` : `${Math.round(tt*9/5+32)}°F`);
        const ptxt = pp==null ? "—" : `${Math.round(pp)}%`;
        $("hoverReadout").innerHTML = `<b>${fmtHour(chart.series.times[i])}</b> • 🌡️ ${ttxt} • 🌧️ ${ptxt}`;
        ctx.restore();
      }
    }

    function onChartMove(ev){
      const rect = chart.canvas.getBoundingClientRect();
      const x = ev.clientX - rect.left;
      const n = chart.series.times.length;
      if (!n) return;

      // pad.left/right заданы в физических пикселях canvas (учитывают devicePixelRatio),
      // поэтому их нужно перевести в CSS-пиксели той же системы координат, что rect.width
      const dpr = Math.max(1, window.devicePixelRatio || 1);
      const pad = chart.bounds;
      const padLeftCSS = pad.left / dpr;
      const padRightCSS = pad.right / dpr;

      const innerW = rect.width - (padLeftCSS + padRightCSS);
      const r = clamp((x - padLeftCSS) / Math.max(1, innerW), 0, 1);
      const i = Math.round(r * (n-1));
      state.chart.hover = i;
      drawChart();
    }

    // ============================
    // Particles (fx canvas)
    // ============================
    const fx = {
      canvas: null, ctx: null,
      mode: "none", // rain|snow|stars|fog|none
      isDay: true,
      parts: [],
      t: 0
    };

    function fxSetMode(kind, isDay){
      fx.isDay = !!isDay;

      // map weather kind to particles
      let mode = "none";
      if (kind === "rain" || kind === "drizzle") mode = "rain";
      else if (kind === "snow") mode = "snow";
      else if (kind === "fog") mode = "fog";
      else if (kind === "thunder") mode = "rain";
      else if (kind === "sun" || kind === "cloud-sun" || kind === "cloud"){
        mode = fx.isDay ? "none" : "stars";
      }

      if (fx.mode !== mode){
        fx.mode = mode;
        fxReset();
      }
    }

    function fxInit(){
      fx.canvas = $("fx");
      fx.ctx = fx.canvas.getContext("2d");
      window.addEventListener("resize", fxResize);
      fxResize();
      fxReset();
      requestAnimationFrame(fxLoop);
    }

    function fxResize(){
      const dpr = Math.max(1, window.devicePixelRatio || 1);
      fx.canvas.width = Math.floor(innerWidth * dpr);
      fx.canvas.height = Math.floor(innerHeight * dpr);
    }

    function fxReset(){
      fx.parts = [];
      const dpr = Math.max(1, window.devicePixelRatio || 1);
      const w = fx.canvas.width, h = fx.canvas.height;

      const count = fx.mode === "rain" ? Math.round((w*h)/(dpr*dpr)/18000)
                  : fx.mode === "snow" ? Math.round((w*h)/(dpr*dpr)/26000)
                  : fx.mode === "stars" ? Math.round((w*h)/(dpr*dpr)/30000)
                  : fx.mode === "fog" ? 18 : 0;

      for (let i=0;i<count;i++){
        fx.parts.push(fxSpawn(w,h));
      }
    }

    function rand(a,b){ return a + Math.random()*(b-a); }

    function fxSpawn(w,h){
      if (fx.mode === "rain"){
        return { x: rand(0,w), y: rand(-h,h), vy: rand(10,18), vx: rand(-1.8, .6), len: rand(10,22), a: rand(.10,.24) };
      }
      if (fx.mode === "snow"){
        return { x: rand(0,w), y: rand(-h,h), vy: rand(1.2,2.6), vx: rand(-.7,.7), r: rand(1.4,3.2), a: rand(.10,.22), tw: rand(0,6.28) };
      }
      if (fx.mode === "stars"){
        return { x: rand(0,w), y: rand(0,h*.7), r: rand(.9,1.8), a: rand(.05,.16), tw: rand(0,6.28) };
      }
      if (fx.mode === "fog"){
        return { x: rand(-w*.1,w*1.1), y: rand(0,h), r: rand(90,180), vx: rand(-0.25,0.25), a: rand(.03,.07) };
      }
      return { x:0,y:0 };
    }

    function fxLoop(ts){
      const ctx = fx.ctx;
      const w = fx.canvas.width, h = fx.canvas.height;
      fx.t = ts * 0.001;

      ctx.clearRect(0,0,w,h);

      if (fx.mode === "rain"){
        ctx.save();
        ctx.lineWidth = Math.max(1, (window.devicePixelRatio||1));
        for (const p of fx.parts){
          p.x += p.vx * (window.devicePixelRatio||1) * 0.8;
          p.y += p.vy * (window.devicePixelRatio||1) * 0.9;

          if (p.y > h+40 || p.x < -40 || p.x > w+40){
            Object.assign(p, fxSpawn(w,h));
            p.y = rand(-200, -40);
          }
          ctx.strokeStyle = `rgba(255,255,255,${p.a})`;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x + p.vx*4, p.y + p.len*(window.devicePixelRatio||1));
          ctx.stroke();
        }
        ctx.restore();
      } else if (fx.mode === "snow"){
        ctx.save();
        for (const p of fx.parts){
          p.tw += 0.02;
          p.x += (p.vx + Math.sin(p.tw)*0.25) * (window.devicePixelRatio||1);
          p.y += p.vy * (window.devicePixelRatio||1);

          if (p.y > h+20){
            Object.assign(p, fxSpawn(w,h));
            p.y = rand(-120,-10);
          }
          if (p.x < -30) p.x = w+30;
          if (p.x > w+30) p.x = -30;

          ctx.fillStyle = `rgba(255,255,255,${p.a})`;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r*(window.devicePixelRatio||1), 0, Math.PI*2);
          ctx.fill();
        }
        ctx.restore();
      } else if (fx.mode === "stars"){
        ctx.save();
        for (const p of fx.parts){
          const pulse = 0.6 + 0.4*Math.sin(fx.t*1.3 + p.tw);
          ctx.fillStyle = `rgba(255,255,255,${p.a * pulse})`;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r*(window.devicePixelRatio||1), 0, Math.PI*2);
          ctx.fill();
        }
        ctx.restore();
      } else if (fx.mode === "fog"){
        ctx.save();
        for (const p of fx.parts){
          p.x += p.vx * (window.devicePixelRatio||1);
          if (p.x < -p.r*1.2) p.x = w + p.r*1.2;
          if (p.x > w + p.r*1.2) p.x = -p.r*1.2;

          ctx.fillStyle = `rgba(255,255,255,${p.a})`;
          ctx.beginPath();
          ctx.ellipse(p.x, p.y, p.r*(window.devicePixelRatio||1), (p.r*0.6)*(window.devicePixelRatio||1), 0, 0, Math.PI*2);
          ctx.fill();
        }
        ctx.restore();
      }

      requestAnimationFrame(fxLoop);
    }

    // ============================
    // Main events & flow
    // ============================
    $("tabToday").addEventListener("click", ()=> setMode("today"));
    $("tabWeek").addEventListener("click", ()=> setMode("week"));

    $("chipTemp").addEventListener("click", ()=>{
      state.chart.showTemp = !state.chart.showTemp;
      $("chipTemp").style.opacity = state.chart.showTemp ? "1" : ".55";
      drawChart();
    });
    $("chipPop").addEventListener("click", ()=>{
      state.chart.showPop = !state.chart.showPop;
      $("chipPop").style.opacity = state.chart.showPop ? "1" : ".55";
      drawChart();
    });

    $("unitBtn").addEventListener("click", () => {
      state.unit = (state.unit === "c") ? "f" : "c";
      $("unitTag").textContent = state.unit === "c" ? "°C" : "°F";
      setStatus(state.unit === "c" ? "Единицы: °C" : "Единицы: °F");
      if (state.latestData && state.selected){
        render(state.latestData, state.selected);
      }
    });

    $("locBtn").addEventListener("click", () => {
      if (!navigator.geolocation){
        setStatus("Геолокация не поддерживается в этом браузере.");
        return;
      }
      setStatus("Определяю местоположение…");
      navigator.geolocation.getCurrentPosition(async (pos) => {
        const lat = pos.coords.latitude;
        const lon = pos.coords.longitude;
        const place = { name: "Текущее место", admin: "", country: "", lat, lon };
        $("q").value = "";
        closeSuggest();
        await loadForPlace(place);
      }, (err) => {
        console.error(err);
        setStatus("Не удалось получить геолокацию (проверь разрешения).");
      }, { enableHighAccuracy: true, timeout: 10000 });
    });

    // Search input handlers
    $("q").addEventListener("input", (e) => {
      const val = e.target.value.trim();
      state.lastQuery = val;

      if (state.geoTimer) clearTimeout(state.geoTimer);

      if (!val){
        closeSuggest();
        return;
      }

      //чтобы подсказки были “по вводу”
      state.geoTimer = setTimeout(async () => {
        if (state.lastQuery !== val) return;
        try{
          const js = await geoSearch(val);
          const resRaw = (js.results || []).map(normalizeGeoResult);

          // иногда API отдаёт “широко”, поэтому фильтруем/сортируем локально
          const res = filterResultsLocally(resRaw, val).slice(0, 8);

          renderSuggestions(res, val);
        }catch(err){
          console.error(err);
          closeSuggest();
        }
      }, 160);
    });

    $("q").addEventListener("keydown", (e) => {
      const open = $("suggest").classList.contains("show");
      if (!open) return;

      if (e.key === "ArrowDown"){
        e.preventDefault();
        setActiveSuggest(state.suggest.active + 1);
      } else if (e.key === "ArrowUp"){
        e.preventDefault();
        setActiveSuggest(state.suggest.active - 1);
      } else if (e.key === "Enter"){
        e.preventDefault();
        pickSuggest(state.suggest.active);
      } else if (e.key === "Escape"){
        e.preventDefault();
        closeSuggest();
      }
    });

    document.addEventListener("click", (e) => {
      const within = e.target.closest(".search");
      if (!within) closeSuggest();
    });

    // ============================
    // Auth: обработчики событий UI
    // ============================
    $("authBtn").addEventListener("click", () => {
      if (state.user){
        handleLogout();
      } else {
        openAuthModal("login");
      }
    });
    $("authClose").addEventListener("click", closeAuthModal);
    $("authOverlay").addEventListener("click", (e) => {
      if (e.target === $("authOverlay")) closeAuthModal();
    });
    $("goRegister").addEventListener("click", () => showAuthView("register"));
    $("goLogin").addEventListener("click", () => showAuthView("login"));
    $("loginSubmit").addEventListener("click", handleLogin);
    $("registerSubmit").addEventListener("click", handleRegister);
    $("loginPassword").addEventListener("keydown", (e) => { if (e.key === "Enter") handleLogin(); });
    $("regPassword").addEventListener("keydown", (e) => { if (e.key === "Enter") handleRegister(); });
    $("favStarBtn").addEventListener("click", toggleFavoriteCurrent);
    $("exportBtn").addEventListener("click", handleExportCSV);
    $("clearHistoryBtn").addEventListener("click", clearHistory);

    // ============================
    // Init
    // ============================
    (async function init(){
      fxInit();
      renderSkeleton();
      setStatus("Готово. Начни вводить город.");
      setMode("today");

      // default = Zagreb
      try{
        const js = await geoSearch("Zagreb");
        const pick = js.results?.[0];
        if (pick){
          const p = normalizeGeoResult(pick);
          $("q").value = "Zagreb";
          await loadForPlace(p);
        }else{
          setStatus("Введите город для старта.");
        }
      }catch{
        setStatus("Введите город для старта.");
      }
    })();
